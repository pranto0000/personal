const mobile_bars = document.querySelector(".mobile_bars");
const main_manu = document.querySelector(".main_manu");
mobile_bars.onclick=function () {
  main_manu.classList.toggle("")
}


















// mobile_bars.addEventListener("click", () => {
//   document.querySelector(".main_manu").classList.toggle("open");
// });